title: 我在 GitHub 上的开源项目
date: '2019-11-27 09:43:28'
updated: '2019-11-27 09:43:28'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [picture](https://github.com/YiYi666/picture) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/YiYi666/picture/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/YiYi666/picture/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/YiYi666/picture/network/members "分叉数")</span>





---

### 2. [jeecg666](https://github.com/YiYi666/jeecg666) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/YiYi666/jeecg666/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/YiYi666/jeecg666/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/YiYi666/jeecg666/network/members "分叉数")</span>





---

### 3. [easybuy](https://github.com/YiYi666/easybuy) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/YiYi666/easybuy/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/YiYi666/easybuy/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/YiYi666/easybuy/network/members "分叉数")</span>

首次提交



---

### 4. [generatorSqlmapCustom](https://github.com/YiYi666/generatorSqlmapCustom) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/YiYi666/generatorSqlmapCustom/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/YiYi666/generatorSqlmapCustom/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/YiYi666/generatorSqlmapCustom/network/members "分叉数")</span>

mybatis 逆行工程



---

### 5. [jk_parent](https://github.com/YiYi666/jk_parent) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/YiYi666/jk_parent/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/YiYi666/jk_parent/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/YiYi666/jk_parent/network/members "分叉数")</span>

jk 项目



---

### 6. [CRM](https://github.com/YiYi666/CRM) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/YiYi666/CRM/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/YiYi666/CRM/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/YiYi666/CRM/network/members "分叉数")</span>

首次提交 CRM 代码

